import java.util.Scanner;
import java.util.Random;
public class Piboy {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		Random rand = new Random();
		
//Inimigos---------------------------------------------------------------------------------------------------------------
		
		String inimigos[] = {"Esqueleto", "Goblin", "Lobisomen","Orc","Bruxa","Ciclope"};
		int vidaEsqueleto = 45, vidaGoblin = 60, vidaLobisomen = 80, vidaOrc = 100, vidaBruxa = 70, vidaCiclope = 200;
		int danoEsqueleto = 20, danoGoblin = 30, danoLobisomen = 35, danoOrc = 40,	danoBruxa = 70, danoCiclope = 99;
		
//Jogador-------------------------------------------------------------------------------------------------------------
		
		int vida = 100;
		int danoPlayer = 17;
		int numPocao = 3;
		int curaPocao = 50;
		int dropPocao = 60;
		
		boolean comecar = true;
		
		System.out.println("⚔️🛡️ PIBOY ADVENTURE ⚔️🛡️");
		System.out.println("==============================================================");
		
		while(comecar) {
			
			System.out.println("O primeiro inimigo é : "+inimigos[0]);
			System.out.println("HP Inimigo: "+vidaEsqueleto);
			System.out.println("==============================================================");
		
//INIMIGO ESQUELETO	--------------------------------------------------------------------------------------------------------
			
		while(vidaEsqueleto>0) {
			
			System.out.println("Seu HP é: "+vida);
			System.out.println("O que voce quer fazer?");
			
			System.out.println("\t* 1. 🗡 Atacar \n");
			System.out.println("\t* 2. 🧉 Usar poçao \n");
			
			 
			
			String pular = input.nextLine();
			if(pular.equals("1")) {
				int danoCausado = danoPlayer;
				int danoSofrido = rand.nextInt(danoEsqueleto);
				vidaEsqueleto -= danoCausado;
				vida -= danoSofrido;
				
				System.out.println("🤺 Voce atingiu o "+ inimigos[0] + " com um dano de "  +danoCausado);
				System.out.println("💥 Voce foi atingido pelo "+inimigos[0] + " com um dano de "+danoSofrido);
				if(vida <1) {
				
				break;
			}
			}else if(pular.equals("2")) {
				if(numPocao>0) {
					vida += curaPocao;
					numPocao --;
					System.out.println("Voce utilizou uma pocao, voce curou "+curaPocao + " de HP");
					System.out.println("Voce tem: " +numPocao);
				}else
					System.out.println("Voce esta sem pocoes ");
				
				
				
			
			}else
				System.out.println("Comando invalido");
				
	}		if(vida<1) {
				System.out.println("💀 Voce morreu 💀");
				break;
	}		
	
				System.out.println("==============================================================");
				System.out.println("# Voce derrotou o inimigo #");
				System.out.println("# Voce obteve 30 de xp #");
				System.out.println("# Voce upou para o nível 2 #");
				System.out.println("==================================");
				System.out.println("Voce ainda tem " + vida + " de HP");
			if(rand.nextInt(100) < dropPocao ) {
				numPocao++;
				System.out.println("==============================================================");
				System.out.println("O inimigo dropou uma pocao de vida, voce esta com "+numPocao);
				System.out.println("==============================================================");
			}
			
				System.out.println("O que vc quer fazer?");
				System.out.println("1. Continuar para o proximo inimigo");
				System.out.println("2. Sair");
				String pular = input.nextLine();
			
			while(!pular.equals("1") && !pular.equals("2") ) {
				System.out.println("Comando invalido");
				pular = input.nextLine();
		}	if(pular.equals("1")) {
				System.out.println("⚔️ Indo para o proximo inimigo");
				pular = input.nextLine();
		}	
			else if(pular.equals("2")){
				System.out.println("Voce saiu do jogo");
				pular = input.nextLine();
			}
		
//INIMIGO GOBLIN------------------------------------------------------------------------------------------------------------
		
		while(vidaGoblin>0) {
				System.out.println("O segundo inimigo é : "+inimigos[1]);
				System.out.println("HP Inimigo: "+vidaGoblin);
				System.out.println("==============================================================");
				System.out.println("Seu HP é: "+vida);
				System.out.println("O que voce quer fazer?");
			
				System.out.println("\t* 1. 🗡 Atacar \n");
				System.out.println("\t* 2. 🧉 Usar poçao \n");
			
			 
			
			String pular2 = input.nextLine();
			if(pular2.equals("1")) {
				danoPlayer = 20;
				int danoCausado = danoPlayer;
				int danoSofrido = rand.nextInt(danoGoblin);
				vidaGoblin -= danoCausado;
				vida -= danoSofrido;
				
				System.out.println("🤺 Voce atingiu o "+ inimigos[1] + " com um dano de "  +danoCausado);
				System.out.println("💥 Voce foi atingido pelo "+inimigos[1] + " com um dano de "+danoSofrido);
				if(vida <1) {
				
				break;
			}
			}else if(pular2.equals("2")) {
				if(numPocao>0) {
					vida += curaPocao;
					numPocao --;
					System.out.println("Voce utilizou uma pocao, voce curou "+curaPocao + " de HP");
					System.out.println("Voce tem: " +numPocao);
				}else
					System.out.println("Voce esta sem pocoes ");
				
				
				
			
			}else
				System.out.println("Comando invalido");
				
	}		if(vida<1) {
				System.out.println("💀 Voce morreu 💀");
				break;
	}		
	
				System.out.println("==============================================================");
				System.out.println("# Voce derrotou o inimigo #");
				System.out.println("# Voce obteve 70 de xp #");
				System.out.println("# Voce upou para o nível 3 #");
				System.out.println("==================================");
				System.out.println("Voce ainda tem " + vida + " de HP");
			if(rand.nextInt(100) < dropPocao ) {
				numPocao++;
				System.out.println("==============================================================");
				System.out.println("O inimigo dropou uma pocao de vida, voce esta com "+numPocao);
				System.out.println("==============================================================");
			}
			
				System.out.println("O que vc quer fazer?");
				System.out.println("1. Continuar para o proximo inimigo");
				System.out.println("2. Sair");
				String pular2 = input.nextLine();
			
			while(!pular2.equals("1") && !pular2.equals("2") ) {
				System.out.println("Comando invalido");
				pular = input.nextLine();
		}	if(pular2.equals("1")) {
				System.out.println("⚔️ Indo para o proximo inimigo");
				pular2 = input.nextLine();
		}	
			else if(pular2.equals("2")){
				System.out.println("Voce saiu do jogo");
				pular2 = input.nextLine();
			}
		
		
//INIMIGO LOBISOMEN------------------------------------------------------------------------------------------------------
		
		while(vidaLobisomen>0) {
			
			System.out.println("O terceiro inimigo é : "+inimigos[2]);
			System.out.println("HP Inimigo: "+vidaLobisomen);
			System.out.println("==============================================================");
			
			System.out.println("Seu HP é: "+vida);
			System.out.println("O que voce quer fazer?");
			
			System.out.println("\t* 1. 🗡 Atacar \n");
			System.out.println("\t* 2. 🧉 Usar poçao \n");
			
			 
			
			String pular3 = input.nextLine();
			if(pular3.equals("1")) {
				danoPlayer = 23;
				int danoCausado = danoPlayer;
				int danoSofrido = rand.nextInt(danoLobisomen);
				vidaLobisomen -= danoCausado;
				vida -= danoSofrido;
				
				System.out.println("🤺 Voce atingiu o "+ inimigos[2] + " com um dano de "  +danoCausado);
				System.out.println("💥 Voce foi atingido pelo "+inimigos[2] + " com um dano de "+danoSofrido);
				if(vida <1) {
				
				break;
			}
			}else if(pular3.equals("2")) {
				if(numPocao>0) {
					vida += curaPocao;
					numPocao --;
					System.out.println("Voce utilizou uma pocao, voce curou "+curaPocao + " de HP");
					System.out.println("Voce tem: " +numPocao);
				}else
					System.out.println("Voce esta sem pocoes ");
				
				
				
			
			}else
				System.out.println("Comando invalido");
				
	}		if(vida<1) {
				System.out.println("💀 Voce morreu 💀");
				break;
	}		
	
				System.out.println("==============================================================");
				System.out.println("# Voce derrotou o inimigo #");
				System.out.println("# Voce obteve 100 de xp #");
				System.out.println("# Voce upou para o nível 4 #");
				System.out.println("==================================");
				System.out.println("Voce ainda tem " + vida + " de HP");
			if(rand.nextInt(100) < dropPocao ) {
				numPocao++;
				System.out.println("==============================================================");
				System.out.println("O inimigo dropou uma pocao de vida, voce esta com "+numPocao);
				System.out.println("==============================================================");
			}
			
				System.out.println("O que vc quer fazer?");
				System.out.println("1. Continuar para o proximo inimigo");
				System.out.println("2. Sair");
				String pular3 = input.nextLine();
			
			while(!pular3.equals("1") && !pular3.equals("2") ) {
				System.out.println("Comando invalido");
				pular3 = input.nextLine();
		}	if(pular3.equals("1")) {
				System.out.println("⚔️ Indo para o proximo inimigo");
				pular3 = input.nextLine();
		}	
			else if(pular3.equals("2")){
				System.out.println("Voce saiu do jogo");
				pular3 = input.nextLine();
	}
		
//INIMIGO ORC---------------------------------------------------------------------------------------------------------
		while(vidaOrc>0) {
			
			System.out.println("O primeiro inimigo é : "+inimigos[3]);
			System.out.println("HP Inimigo: "+vidaOrc);
			System.out.println("==============================================================");
	
			System.out.println("Seu HP é: "+vida);
			System.out.println("O que voce quer fazer?");
			
			System.out.println("\t* 1.  🗡 Atacar \n");
			System.out.println("\t* 2. 🧉 Usar poçao \n");
			
			 
			
			String pular4 = input.nextLine();
			if(pular4.equals("1")) {
				danoPlayer = 30;
				int danoCausado = danoPlayer;
				int danoSofrido = rand.nextInt(danoOrc);
				vidaOrc -= danoCausado;
				vida -= danoSofrido;
				
				System.out.println("🤺 Voce atingiu o "+ inimigos[3] + " com um dano de "  +danoCausado);
				System.out.println("💥 Voce foi atingido pelo "+inimigos[3] + " com um dano de "+danoSofrido);
				if(vida <1) {
				
				break;
			}
			}else if(pular4.equals("2")) {
				if(numPocao>0) {
					vida += curaPocao;
					numPocao --;
					System.out.println("Voce utilizou uma pocao, voce curou "+curaPocao + " de HP");
					System.out.println("Voce tem: " +numPocao);
				}else
					System.out.println("Voce esta sem pocoes ");
				
				
				
			
			}else
				System.out.println("Comando invalido");
				
	}		if(vida<1) {
				System.out.println("💀 Voce morreu 💀");
				break;
	}		
	
				System.out.println("==============================================================");
				System.out.println("# Voce derrotou o inimigo #");
				System.out.println("# Voce obteve 180 de xp #");
				System.out.println("# Voce upou para o nivel 5 #");
				System.out.println("==================================");
				System.out.println("Voce ainda tem " + vida + " de HP");
			if(rand.nextInt(100) < dropPocao ) {
				numPocao++;
				System.out.println("==============================================================");
				System.out.println("O inimigo dropou uma pocao de vida, voce esta com "+numPocao);
				System.out.println("==============================================================");
			}
			
				System.out.println("O que vc quer fazer?");
				System.out.println("1. Continuar para o proximo inimigo");
				System.out.println("2. Sair");
				String pular4 = input.nextLine();
			
			while(!pular4.equals("1") && !pular4.equals("2") ) {
				System.out.println("Comando invalido");
				pular4 = input.nextLine();
		}	if(pular4.equals("1")) {
				System.out.println("⚔️ Indo para o proximo inimigo");
				pular4 = input.nextLine();
		}	
			else if(pular4.equals("2")){
				System.out.println("Voce saiu do jogo");
				pular4 = input.nextLine();
		}
		
//INIMIGO BRUXA------------------------------------------------------------------------------------------------
		while(vidaBruxa>0) {
			
			System.out.println("O primeiro inimigo é : "+inimigos[4]);
			System.out.println("HP Inimigo: "+vidaBruxa);
			System.out.println("======================");
			
			System.out.println("Seu HP é: "+vida);
			System.out.println("O que voce quer fazer?");
			
			System.out.println("\t* 1. 🗡 Atacar \n");
			System.out.println("\t* 2. 🧉 Usar poçao \n");
			
			 
			
			String pular5 = input.nextLine();
			if(pular5.equals("1")) {
				danoPlayer = 30;
				int danoCausado = danoPlayer;
				int danoSofrido = rand.nextInt(danoBruxa);
				vidaBruxa -= danoCausado;
				vida -= danoSofrido;
				
				System.out.println("🤺 Voce atingiu o "+ inimigos[4] + " com um dano de "  +danoCausado);
				System.out.println("💥 Voce foi atingido pelo "+inimigos[4] + " com um dano de "+danoSofrido);
				if(vida <1) {
				
				break;
			}
			}else if(pular5.equals("2")) {
				if(numPocao>0) {
					vida += curaPocao;
					numPocao --;
					System.out.println("Voce utilizou uma pocao, voce curou "+curaPocao + " de HP");
					System.out.println("Voce tem: " +numPocao);
				}else
					System.out.println("Voce esta sem pocoes ");
				
				
				
			
			}else
				System.out.println("Comando invalido");
				
	}		if(vida<1) {
				System.out.println("💀 Voce morreu 💀");
				break;
	}		
	
				System.out.println("==============================================================");
				System.out.println("# Voce derrotou o inimigo #");
				System.out.println("# Voce obteve 300 de xp #");
				System.out.println("# Voce upou para o nível 6 #");
				System.out.println("==================================");
				System.out.println("Voce ainda tem " + vida + " de HP");
			if(rand.nextInt(100) < dropPocao ) {
				numPocao++;
				System.out.println("==============================================================");
				System.out.println("O inimigo dropou uma pocao de vida, voce esta com "+numPocao);
				System.out.println("==============================================================");
			}
			
				System.out.println("O que vc quer fazer?");
				System.out.println("1. Continuar para o proximo inimigo");
				System.out.println("2. Sair");
				String pular5 = input.nextLine();
			
			while(!pular5.equals("1") && !pular5.equals("2") ) {
				System.out.println("Comando invalido");
				pular5 = input.nextLine();
		}	if(pular5.equals("1")) {
				System.out.println("⚔️ Indo para o proximo inimigo");
				pular5 = input.nextLine();
		}	
			else if(pular5.equals("2")){
				System.out.println("Voce saiu do jogo");
				pular5 = input.nextLine();
			}
		
//INIMIGO CICLOPE------------------------------------------------------------------------------------------------------
		while(vidaCiclope>0) {
			
			System.out.println("O Ultimo inimigo é : "+inimigos[5]);
			System.out.println("HP Inimigo: "+vidaCiclope);
			System.out.println("==============================================================");
	
			System.out.println("Seu HP é: "+vida);
			System.out.println("O que voce quer fazer?");
			
			System.out.println("\t* 1. 🗡 Atacar \n");
			System.out.println("\t* 2. 🧉 Usar poçao \n");
			
			 
			
			String pular6 = input.nextLine();
			if(pular6.equals("1")) {
				danoPlayer = 80;
				int danoCausado = danoPlayer;
				int danoSofrido = rand.nextInt(danoCiclope);
				vidaCiclope -= danoCausado;
				vida -= danoSofrido;
				
				System.out.println("🤺 Voce atingiu o "+ inimigos[5] + " com um dano de "  +danoCausado);
				System.out.println("💥 Voce foi atingido pelo "+inimigos[5] + " com um dano de "+danoSofrido);
				if(vida <1) {
				
				break;
			}
			}else if(pular6.equals("2")) {
				if(numPocao>0) {
					vida += curaPocao;
					numPocao --;
					System.out.println("Voce utilizou uma pocao, voce curou "+curaPocao + " de HP");
					System.out.println("Voce tem: " +numPocao);
				}else
					System.out.println("Voce esta sem pocoes ");
				
				
				
			
			}else
				System.out.println("Comando invalido");
				
	}		if(vida<1) {
				System.out.println("💀 Voce morreu 💀");
				break;
	}		
				System.out.println("Voce matou o CICLOPE ");
				
// FIM DO JOGO E CREDITOS -------------------------------------------------------------------------------------------	
				System.out.println("==============================================================");
				System.out.println("🎇 Parabens! Voce conseguiu finalizar o jogo! #");
				System.out.println("==============================================================");
				System.out.println("Créditos");
				System.out.println("\t Fabrício"
								+ "\n\t Jayson"
								+ "\n\t Lucas"
								+ "\n\t Marcus"
								+ "\n\t Murilo");
				
			break;
			
				
}		input.close();
}
}
