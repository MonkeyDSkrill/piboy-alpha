import java.util.Scanner;
import java.util.Random;
public class RPG_BEN10 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Random rand = new Random();
		
		//Aliens e Inimigos
		String aliens [] = {"Chama" , "Ultra-T", "4 Braços" , "Besta" , "Fantasmático", };
		String inimigos[] = {"Aquamen", "Snivy", "Ciborgue", "Charizard"};
		
		int vidaAliens = 100;
		int vidaInimigos = 80;
		int omnitrix = 0;
		int danoAliens = 100;
		int danoInimigos = 100;
		
		
		boolean comecar = true;
		boolean continuar = true;
		
		System.out.println("Jogo do Ben 10");
		
		//randomizar inimigos
		
		while(comecar) { 
			System.out.println("=============================================================================================================================================================================================================");
			
			String randInimigos = inimigos[rand.nextInt(aliens.length)];
			System.out.println("\t# O inimigo que vc irá enfrentar é : " + randInimigos + " #\n" );
			if(randInimigos==inimigos[0]) {
				System.out.println("Este inimigo é um humano-peixe. Ele controla a agua e tem poderes aquaticos");
			}else if(randInimigos==inimigos[1]) {
				System.out.println("Este inimigo é do tipo planta. Ele controla a natureza ao seu redor");
			}else if(randInimigos==inimigos[2])
				System.out.println("Este inimigo é um homem-máquina. Ele possui partes biônicas em seu corpo");
			else
				System.out.println("Este inimigo é do tipo fogo. Ele solta bolas de fogo pela boca");
			
			System.out.println("\t# Digite a o numero 1 para usar o omnitrix #\n");
			omnitrix = input.nextInt();	
			String pular = input.nextLine();
		
			
			
			System.out.println("============================================================================================================================================================================================================");
	
			//randomizar aliens
			
		while(continuar) {
				System.out.println("========================================================================================================================================================================================================");
			
			String randAliens = aliens[rand.nextInt(aliens.length)];
			System.out.println("\t# O alienigena que vc caiu é : " + randAliens + " #\n");
			if(randAliens==aliens[0]) {
				System.out.println("Um ser feito de rochas com Fogo dentro de si , Chama possui a capacidade de manipular o fogo e criar pranchas de rochas flamejantes para se locomover mais rápido .");
			}else if (randAliens==aliens[1]) {
				System.out.println("Esse Alien é muito interessante , pois ele não é um ser orgânico mas sim uma Máquina , Ultra-T possui a habilidade de manipular qualquer tipo de Tecnologia de qualquer planeta");
			}else if (randAliens==aliens[2]) {
				System.out.println("4 Braços , o alienígena que todo mundo gostava , 4 Braços possui super força (pois com Quatro Braços fica fácil né ? ) Além de poder dar saltos a longas distâncias .");
			}else if (randAliens==aliens[3])
				System.out.println("Ah ... Quem não lembra desse alien que parece um cachorro grande , Besta não possui olhos mas em compensação possui uma ecolocalização incrível.");
			else
				System.out.println("Fantasmático um alien tipo fantasma com capacidade de ficar invisível e intangível , porém tomou vontade própria e quis sair do Ominitrix ( e conseguiu ) Após Isso ele recebeu uma fraqueza a Luz Solar .");
			
			
			System.out.println("============================================================================================================================================================================================================");
			
		while(vidaInimigos>0) {
				System.out.println("Seu HP: " +vidaAliens);
				System.out.println("Vida do inimigo"+vidaInimigos);
				System.out.println("O que voce quer fazer?");
				System.out.println("\t1. Digite 1 para atacar");
				System.out.println("\t2. Digite 2 para fugir");
				
			
			String pular2 = input.nextLine();
			
			if(input.equals("1")) {
			if(aliens[0]==inimigos[0])
				System.out.println("Voce perdeu");
			}		
			else if(input.equals("2")){
		}
			else {
				
			}
			
			
			
		}
			
				
				
				
			
				
			
			
		
		
		
		
		
			
			
			
		
		
		
		
	
		}

	}

}
}