import java.util.Scanner;
import java.util.Random;
public class RPG_POKEMON {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		Random rand = new Random();
		
		//Inimigos
		
		String inimigos[] = {"Esqueleto", "Goblin", "Zumbi","Orc","Bruxa","Vampiro", "Demonio","Necromante", "Lobisomen","Gigante"};
		int vidaEsqueleto = 75, vidaGoblin = 100, vidaBruxa = 50;
		int danoEsqueleto = 25, danoGoblin = 35, danoBruxa = 50;
		
		//Jogador
		
		int vida = 100;
		int danoPlayer = 30;
		int numPocao = 3;
		int curaPocao = 40;
		int dropPocao = 50;
		
		boolean comecar = true;
		
		System.out.println("Voce entrou na caverna");
		System.out.println("======================");
		
		while(comecar) {
			
			System.out.println("O primeiro inimigo é : "+inimigos[0]);
			System.out.println("HP Inimigo: "+vidaEsqueleto);
			System.out.println("======================");
			
		while(vidaEsqueleto>0) {
			
			System.out.println("Seu HP é: "+vida);
			System.out.println("O que voce quer fazer?");
			
			System.out.println("\t* 1. Atacar \n");
			System.out.println("\t* 2. Usar poçao \n");
			
			 
			
			String pular = input.nextLine();
			if(pular.equals("1")) {
				int danoCausado = danoPlayer;
				int danoSofrido = danoEsqueleto;
				vidaEsqueleto -= danoCausado;
				vida -= danoSofrido;
				
				System.out.println("Voce atingiu o "+ inimigos[0] + "com um dano de "  +danoCausado);
				System.out.println("Voce foi atingido pelo "+inimigos[0] + "com um dano de "+danoSofrido);
				if(vida <1) {
				
				break;
			}
			}else if(pular.equals("2")) {
				if(numPocao>0) {
					vida += curaPocao;
					numPocao --;
					System.out.println("Voce utilizou uma pocao, voce curou "+curaPocao + " de HP");
					System.out.println("Voce tem: " +numPocao);
				}else
					System.out.println("Voce esta sem pocoes ");
				
				
				
			
			}else
				System.out.println("Comando invalido");
				
	}		if(vida<1) {
				System.out.println("Voce morreu");
				break;
	}		
	
			System.out.println("=================================");
			System.out.println("# Voce derrotou o inimigo #");
			System.out.println("Voce ainda tem " + vida + " de HP");
			if(rand.nextInt(100) < dropPocao ) {
				numPocao++;
				System.out.println("O inimigo dropou uma pocao de vida");
				System.out.println("Voce tem "+numPocao);
			}
			System.out.println("==================================");
			System.out.println("O que vc quer fazer?");
			System.out.println("1. Continuar para o proximo inimigo");
			System.out.println("2. Sair");
			String pular = input.nextLine();
			
			while(!pular.equals("1") && !pular.equals("2") ) {
				System.out.println("Comando invalido");
				pular = input.nextLine();
		}	if(pular.equals("1")) {
				System.out.println("Indo para o proximo inimigo");
				pular = input.nextLine();
		}	
			else if(pular.equals("2")){
				System.out.println("Voce saiu do jogo");
				pular = input.nextLine();
			}
}
	
			
	
	
	
	
	
	
	
	}
}
